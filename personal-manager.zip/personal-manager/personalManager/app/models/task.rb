class Task < ApplicationRecord
  validates :title, :description, :time, presence: true

end
