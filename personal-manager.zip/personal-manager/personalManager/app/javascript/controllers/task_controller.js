import { Controller } from "stimulus";

export default class extends Controller {
    static targets = ["name", "submit"]

    connect() {
        this.submitTarget.disabled = true;
    }

    validate() {
        if (this.nameTarget.value.length > 0) {
            this.submitTarget.disabled = false;
        } else {
            this.submitTarget.disabled = true;
        }
    }
}