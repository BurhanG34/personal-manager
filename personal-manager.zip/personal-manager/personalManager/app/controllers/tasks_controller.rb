class TasksController < ApplicationController
  before_action :set_task, only: [:show, :edit, :update, :destroy]

  # scope :ordered, -> { order(time: :desc) }
  # after_create_commit -> { broadcast_prepend_to "tasks" }
  # after_update_commit -> { broadcast_replace_to "tasks" }
  # after_destroy_commit -> { broadcast_remove_to "tasks" }
  def create
    @task = Task.new(task_params)

    if @task.save
      respond_to do |format|
        format.html { redirect_to tasks_path, notice: "Task was successfully created." }
        format.turbo_stream
      end
    else
      render :new, status: :unprocessable_entity
    end
  end

  def show
  end

  def edit
  end

  def update
    if @task.update(task_params)
      redirect_to tasks_path, notice: "Task was successfully updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @task.destroy
    respond_to do |format|
      format.html { redirect_to tasks_path, notice: "Task was successfully destroyed." }
      format.turbo_stream
    end
  end

  def index
    @tasks = Task.all
  end

  def new
    @task = Task.new
  end

  private

  def set_task
    @task = Task.find(params[:id])
  end

  def task_params
    params.require(:task).permit(:title, :description, :time)
  end
end
